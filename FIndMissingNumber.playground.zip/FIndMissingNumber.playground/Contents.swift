import UIKit

//Given an array containing numbers from 1 to n, with one number missing, find the missing number.

func findMissingNum(_ arr: [Int]) {
    guard let max = arr.max() else { return }
    let sum = max * (max+1)/2
    let total = arr.reduce(0, +)
    print("Missing number = \(sum-total)")
}

findMissingNum([1,2,4,5,6,7,8,9,10])
